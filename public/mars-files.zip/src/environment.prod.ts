export const environment = {
  production: true,
  api: {
    rovers: {
      baseUrl: 'http://localhost:3390',
      apiKey: '',
      isNasa: false,
    },
    photos: {
      baseUrl: 'http://localhost:3390',
      apiKey: '',
      isNasa: false,
    }
    // photos: {
    //   baseUrl: 'https://api.nasa.gov/mars-photos/api/v1',
    //   apiKey: 'api_key=DEMO_KEY',
    //   isNasa: true,
    // }
  }
};
